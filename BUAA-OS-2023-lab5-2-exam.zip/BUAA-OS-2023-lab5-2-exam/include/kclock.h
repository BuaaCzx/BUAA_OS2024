#ifndef _KCLOCK_H_
#define _KCLOCK_H_
#ifndef __ASSEMBLER__
void kclock_init(void);
#endif /* !__ASSEMBLER__ */
#endif
